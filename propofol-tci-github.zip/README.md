# Propofol TCI PK/PD Simulator

Simulador comparativo de modelos farmacocinéticos para propofol en modalidad TCI efecto-sitio.

**Modelos:** Eleveld 2018 · Marsh 1991 · Schnider 1998/1999

**Acceso directo:** https://[tu-usuario].github.io/propofol-tci

## Características
- Gráficos Ce/Cp vs tiempo con zoom, pan y crosshair interactivo
- Tasa de infusión mg/kg/h navegable
- Histéresis Cp–Ce con explorer ke0
- Decrementales context-sensitive desde Ce al paro
- Stop-antes-cierre con simulación inversa
- Parámetros ke0 alométrico Eleveld vs fijo Marsh/Schnider
- Crossmatch vs iTIVA / Stanpump / OpenTCI
- Funciona offline — sin dependencias externas

## Referencias
- Eleveld DJ et al. Br J Anaesth 2018;120:942-959
- Marsh B et al. BJA 1991;67:41-48  
- Schnider TW et al. Anesthesiology 1998;88:1170-82
- White M et al. ke0 Anaesthesia 2008

**Carlos Fuentes 2026**
